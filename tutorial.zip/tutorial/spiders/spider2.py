from scrapy.spiders import SitemapSpider

class MySpider(SitemapSpider):
    name = "site"
    sitemap_urls = ['http://inside-files/robots.txt']

    def parse(self, response):
        pass # ... scrape item here ...